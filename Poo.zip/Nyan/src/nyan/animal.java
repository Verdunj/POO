/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nyan;

/**
 *
 * @author Marie-Eugénie
 */
public class animal {
    protected int age;
    protected  String nom;
    protected String crie;
    
    public animal(int age, String nom,String crie){
        this.age=age;
        this.nom=nom;
        this.crie=crie;
    }

    public String getCrie() {
        return crie;
    }

    public void setCrie(String crie) {
        this.crie = crie;
    }
    
    
}
